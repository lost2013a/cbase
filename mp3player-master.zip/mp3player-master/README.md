基于libmad与alsa的mp3播放器
=====================

编译：<br>
```
git clone https://github.com/xiaoloudongfeng/mp3player.git
cd mp3player
make
